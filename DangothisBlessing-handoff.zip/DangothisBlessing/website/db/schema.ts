import {sqliteTable,text,integer,index,uniqueIndex} from 'drizzle-orm/sqlite-core';
export const giftTargets=sqliteTable('gift_targets',{id:text('id').primaryKey(),target:integer('target')});
export const contributions=sqliteTable('contributions',{
 id:text('id').primaryKey(),giftId:text('gift_id').notNull().references(()=>giftTargets.id),name:text('name').notNull(),amount:integer('amount').notNull(),confirmedAmount:integer('confirmed_amount').notNull().default(0),status:text('status').notNull().default('pending'),bankRef:text('bank_ref'),createdAt:integer('created_at').notNull(),reviewedAt:integer('reviewed_at'),reviewedBy:text('reviewed_by'),reviewToken:text('review_token'),
},t=>[uniqueIndex('idx_contributions_bank_ref').on(t.bankRef),index('idx_contributions_gift_status').on(t.giftId,t.status),index('idx_contributions_status_created').on(t.status,t.createdAt)]);
export const wishes=sqliteTable('wishes',{id:text('id').primaryKey(),name:text('name').notNull(),message:text('message').notNull(),status:text('status').notNull().default('pending'),createdAt:integer('created_at').notNull(),reviewedBy:text('reviewed_by')},t=>[index('idx_wishes_status_created').on(t.status,t.createdAt)]);
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const audit=sqliteTable('audit',{id:text('id').primaryKey(),action:text('action').notNull(),recordId:text('record_id').notNull(),actor:text('actor').notNull(),details:text('details').notNull(),createdAt:integer('created_at').notNull()});
export const rateLimits=sqliteTable('rate_limits',{key:text('key').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()});
