CREATE TABLE `audit` (
	`id` text PRIMARY KEY NOT NULL,
	`action` text NOT NULL,
	`record_id` text NOT NULL,
	`actor` text NOT NULL,
	`details` text NOT NULL,
	`created_at` integer NOT NULL
);

--> statement-breakpoint
CREATE TABLE `contributions` (
	`id` text PRIMARY KEY NOT NULL,
	`gift_id` text NOT NULL,
	`name` text NOT NULL,
	`amount` integer NOT NULL,
	`confirmed_amount` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`bank_ref` text,
	`created_at` integer NOT NULL,
	`reviewed_at` integer,
	`reviewed_by` text,
	`review_token` text,
	FOREIGN KEY (`gift_id`) REFERENCES `gift_targets`(`id`) ON UPDATE no action ON DELETE no action
);

--> statement-breakpoint
CREATE UNIQUE INDEX `idx_contributions_bank_ref` ON `contributions` (`bank_ref`);
--> statement-breakpoint
CREATE INDEX `idx_contributions_gift_status` ON `contributions` (`gift_id`,`status`);
--> statement-breakpoint
CREATE INDEX `idx_contributions_status_created` ON `contributions` (`status`,`created_at`);
--> statement-breakpoint
CREATE TABLE `gift_targets` (
	`id` text PRIMARY KEY NOT NULL,
	`target` integer
);

--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);

--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);

--> statement-breakpoint
CREATE TABLE `wishes` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`message` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` integer NOT NULL,
	`reviewed_by` text
);

--> statement-breakpoint
CREATE INDEX `idx_wishes_status_created` ON `wishes` (`status`,`created_at`);