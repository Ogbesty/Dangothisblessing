import React from 'react';
import {createRoot} from 'react-dom/client';
import Wedding from '../app/wedding';
import AdminAccess from '../app/admin/access';
function App(){return location.pathname==='/admin'?<AdminAccess/>:<Wedding/>}
createRoot(document.getElementById('root')!).render(<App/>);
