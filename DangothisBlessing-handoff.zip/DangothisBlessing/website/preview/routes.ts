export * as wedding from '../app/api/wedding/route';
export * as wishes from '../app/api/wishes/route';
export * as contributions from '../app/api/contributions/route';
export * as admin from '../app/api/admin/route';
export * as session from '../app/api/session/route';
