'use client';

import {useEffect,useState,type CSSProperties} from 'react';

const hearts = Array.from({length:16},(_,i)=>({
  left:5+(i*29)%91,
  delay:(i%5)*0.28,
  duration:3.3+(i%4)*0.25,
  drift:(i%2===0?1:-1)*(25+(i%3)*20),
  size:20+(i%4)*7,
  emoji:['💜','💕','💛','❤️'][i%4],
}));

export default function WelcomeHearts(){
 const [visible,setVisible]=useState(false);
 useEffect(()=>{
   const motion=window.matchMedia('(prefers-reduced-motion: reduce)');
   if(motion.matches)return;
   setVisible(true);
   const timer=window.setTimeout(()=>setVisible(false),5600);
   const stop=()=>{if(motion.matches)setVisible(false)};
   motion.addEventListener('change',stop);
   return()=>{window.clearTimeout(timer);motion.removeEventListener('change',stop)};
 },[]);
 if(!visible)return null;
 return <div className="welcome-hearts" aria-hidden="true">{hearts.map((heart,i)=><span key={i} style={{left:`${heart.left}%`,fontSize:`${heart.size}px`,animationDelay:`${heart.delay}s`,animationDuration:`${heart.duration}s`,'--heart-drift':`${heart.drift}px`} as CSSProperties}>{heart.emoji}</span>)}</div>;
}
