import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Daniel & Blessing | 14 November 2026",
  description: "Celebrate Daniel and Blessing on 14 November 2026 in Lagos. #DangothisBlessing",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}


