import Wedding from '../wedding';
export default function ReviewPage(){return <Wedding/>;}
