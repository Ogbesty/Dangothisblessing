import {api,json,publicData} from '@/lib/server';
export const dynamic='force-dynamic';
export async function GET(){return api(async()=>json(await publicData()))}
