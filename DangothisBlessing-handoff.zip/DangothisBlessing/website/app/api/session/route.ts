import {api,body,json,rateLimit,HttpError} from '@/lib/server';
import {passwordMatches,createSession,passwordAdmin,sessionCookie} from '@/lib/admin-auth';
export const dynamic='force-dynamic';
export async function GET(){return api(async()=>json({authenticated:!!await passwordAdmin()}));}
export async function POST(req:Request){return api(async()=>{const b=await body(req);await rateLimit(req,'admin-login');if(typeof b.password!=='string'||b.password.length>200||!await passwordMatches(b.password))throw new HttpError(401,'Incorrect password.');const response=json({ok:true});response.headers.set('Set-Cookie',sessionCookie(req,await createSession()));return response;});}
export async function DELETE(req:Request){return api(async()=>{await body(req);const response=json({ok:true});response.headers.set('Set-Cookie',sessionCookie(req,''));return response;});}
