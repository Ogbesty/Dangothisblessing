import {api,json,admin,body,db,text,identifier,amount,publicData,HttpError} from '@/lib/server';
export const dynamic='force-dynamic';
export async function GET(){return api(async()=>{const user=await admin();const data=await publicData();const [contributions,wishes,audit]=await Promise.all([db().prepare('SELECT * FROM contributions ORDER BY created_at DESC LIMIT 1000').all(),db().prepare('SELECT * FROM wishes ORDER BY created_at DESC LIMIT 1000').all(),db().prepare('SELECT * FROM audit ORDER BY created_at DESC LIMIT 100').all()]);return json({...data,contributions:contributions.results,wishes:wishes.results,audit:audit.results,email:user.email,localPreview:import.meta.env.DEV})})}
export async function POST(req:Request){return api(async()=>{
 const user=await admin(),b=await body(req),now=Date.now(),token=crypto.randomUUID();
 const log=(action:string,id:string,details:unknown)=>db().prepare('INSERT INTO audit (id,action,record_id,actor,details,created_at) VALUES (?,?,?,?,?,?)').bind(token,action,id,user.email,JSON.stringify(details),now);
 if(b.action==='wish'){
  const id=identifier(b.id);if(!['approved','rejected','pending'].includes(b.status))throw new HttpError(400,'Invalid wish status');
  if(!await db().prepare('SELECT id FROM wishes WHERE id=?').bind(id).first())throw new HttpError(404,'Wish not found');
  await db().batch([db().prepare('UPDATE wishes SET status=?,reviewed_by=? WHERE id=?').bind(b.status,user.email,id),log('wish-status',id,{status:b.status})]);return json({ok:true});
 }
 if(b.action==='confirm'){
  const id=identifier(b.id),value=amount(b.amount),bankRef=text(b.bankRef,3,120,'Bank transaction reference').toUpperCase();
  const receiptReference=text(b.receiptReference,8,60,'Contribution reference from WhatsApp');
  if(receiptReference!==id)throw new HttpError(400,'The contribution reference from WhatsApp does not match this contribution. Check the message and try again.');
  if(b.receiptChecked!==true||b.bankCreditChecked!==true)throw new HttpError(400,'Check both the WhatsApp receipt and the actual bank credit before confirming.');
  const item=await db().prepare('SELECT * FROM contributions WHERE id=?').bind(id).first<{id:string;status:string;gift_id:string}>();if(!item)throw new HttpError(404,'Contribution not found');if(item.status==='confirmed')throw new HttpError(409,'This contribution is already confirmed.');
  const existing=await db().prepare('SELECT id FROM contributions WHERE bank_ref=? AND id<>?').bind(bankRef,id).first();if(existing)throw new HttpError(409,'That bank transaction has already been recorded.');
  const query=db().prepare("UPDATE contributions SET status='confirmed',confirmed_amount=?,bank_ref=?,reviewed_by=?,reviewed_at=?,review_token=? WHERE id=? AND status='pending' AND ((SELECT target FROM gift_targets WHERE id=contributions.gift_id) IS NULL OR ?+(SELECT COALESCE(SUM(other.confirmed_amount),0) FROM contributions other WHERE other.gift_id=contributions.gift_id AND other.status='confirmed') <= (SELECT target FROM gift_targets WHERE id=contributions.gift_id))").bind(value,bankRef,user.email,now,token,id,value);
  const result=await db().batch([query,db().prepare("INSERT INTO audit (id,action,record_id,actor,details,created_at) SELECT ?,'confirm',id,?,?,? FROM contributions WHERE id=? AND review_token=?").bind(token,user.email,JSON.stringify({amount:value,bankRef,receiptReference,receiptChecked:true,bankCreditChecked:true}),now,id,token)]);
  if(!result[0].meta.changes)throw new HttpError(409,'This payment exceeds the remaining target, or the contribution was already reviewed. Keep it pending while you arrange a refund or agree a different allocation with the guest.');return json({ok:true});
 }
 if(b.action==='reject'||b.action==='reopen'){
  const id=identifier(b.id),reason=text(b.reason,5,500,'Reason');const target=b.action==='reject'?'rejected':'pending';
  const prior=await db().prepare('SELECT * FROM contributions WHERE id=?').bind(id).first();if(!prior)throw new HttpError(404,'Contribution not found');
  await db().batch([db().prepare('UPDATE contributions SET status=?,confirmed_amount=0,reviewed_at=?,reviewed_by=? WHERE id=?').bind(target,now,user.email,id),log(b.action,id,{reason,previous:prior})]);return json({ok:true});
 }
 if(b.action==='target'){
  const id=text(b.id,1,50,'Gift');if(id==='cash')throw new HttpError(400,'Cash gifts have no target');const value=amount(b.target);
  const result=await db().batch([db().prepare("UPDATE gift_targets SET target=? WHERE id=? AND ? >= (SELECT COALESCE(SUM(confirmed_amount),0) FROM contributions WHERE gift_id=? AND status='confirmed')").bind(value,id,value,id),db().prepare("INSERT INTO audit (id,action,record_id,actor,details,created_at) SELECT ?,'target',id,?,?,? FROM gift_targets WHERE id=? AND target=?").bind(token,user.email,JSON.stringify({target:value}),now,id,value)]);
  if(!result[0].meta.changes)throw new HttpError(409,'The target cannot be lower than confirmed contributions.');return json({ok:true});
 }
 if(b.action==='content'){
  const story=text(b.story,20,25000,'Love story'),invitation=text(b.invitation,20,2000,'Invitation');
  await db().batch([db().prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('story',story),db().prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('invitation',invitation),log('content','wedding',{story,invitation})]);return json({ok:true});
 }
 throw new HttpError(400,'Unknown action');
})}
