$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$weddingNode = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $weddingNode) { $weddingNode = 'C:\Users\USER\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' }
& $weddingNode scripts/build-local-preview.mjs
if ($LASTEXITCODE -ne 0) { throw 'The preview build failed.' }
Write-Host 'Wedding preview: http://127.0.0.1:5173/ — keep this window open.'
& $weddingNode scripts/local-preview.mjs
