import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {AsyncLocalStorage} from 'node:async_hooks';
import {pathToFileURL} from 'node:url';
export function sqliteBinding(file){
 const database=new DatabaseSync(file);database.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');
 database.exec('CREATE TABLE IF NOT EXISTS _preview_migrations (name TEXT PRIMARY KEY)');
 const migrations=fs.readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort();
 for(const file of migrations){if(database.prepare('SELECT name FROM _preview_migrations WHERE name=?').get(file))continue;database.exec('BEGIN');try{database.exec(fs.readFileSync(path.join('drizzle',file),'utf8'));database.prepare('INSERT INTO _preview_migrations(name) VALUES (?)').run(file);database.exec('COMMIT')}catch(e){database.exec('ROLLBACK');throw e}}
 function statement(sql,values=[]){const run=()=>{const result=database.prepare(sql).run(...values);return {success:true,meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}}};return {bind:(...args)=>statement(sql,args),run:async()=>run(),all:async()=>({success:true,results:database.prepare(sql).all(...values),meta:{}}),first:async(column)=>{const r=database.prepare(sql).get(...values);return r?(column?r[column]:r):null},_run:run}}
 return {prepare:statement,batch:async statements=>{database.exec('BEGIN');try{const results=statements.map(s=>s._run());database.exec('COMMIT');return results}catch(e){database.exec('ROLLBACK');throw e}},close:()=>database.close(),raw:database};
}
export async function startPreview({port=5173,databaseFile='.sites-runtime/preview/wedding.sqlite',authSecrets}={}){
 fs.mkdirSync(path.dirname(databaseFile),{recursive:true});const binding=sqliteBinding(databaseFile);const secrets=authSecrets||JSON.parse(fs.readFileSync('.sites-runtime/admin-secrets.json','utf8'));globalThis.__weddingPreviewEnv={DB:binding,...secrets};globalThis.__weddingPreviewContext=new AsyncLocalStorage();
 const routes=await import(pathToFileURL(path.resolve('.sites-runtime/preview/routes.mjs'))+'?'+Date.now());
 const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Daniel & Blessing | 14 November 2026</title><meta name="description" content="Join Daniel and Blessing as our forever begins on 14 November 2026."><link rel="icon" href="/favicon.svg"><link rel="stylesheet" href="/style.css"></head><body><div id="root"></div><script type="module" src="/app.js"></script></body></html>';
 const server=http.createServer(async(req,res)=>{
  try{
   const expected=new Set([`127.0.0.1:${port}`,`localhost:${port}`]);if(!expected.has(req.headers.host)){res.writeHead(403);res.end('Local preview only');return;}
   const url=new URL(req.url,`http://${req.headers.host}`);res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
   if(url.pathname.startsWith('/api/')){
    const name=url.pathname.slice(5);const route=routes[name];const action=route?.[req.method];if(!action){res.writeHead(404);res.end();return;}
    let body='';for await(const chunk of req){body+=chunk;if(body.length>50000){res.writeHead(413);res.end();return;}}
    const headers=new Headers();for(const [key,value] of Object.entries(req.headers)){if(key.startsWith('oai-')||key==='cf-connecting-ip')continue;if(value)headers.set(key,Array.isArray(value)?value.join(','):value)}headers.set('cf-connecting-ip','127.0.0.1');
    const request=new Request(url,{method:req.method,headers,...(body?{body}:{} )});
    const response=await globalThis.__weddingPreviewContext.run({headers},()=>action(request));res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
   }
   if(url.pathname==='/'||url.pathname==='/admin'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
   const files={'/app.js':'.sites-runtime/preview/app.js','/style.css':'.sites-runtime/preview/style.css'};
   let file=files[url.pathname];if(!file){const base=path.resolve('public');file=path.resolve(base,'.'+decodeURIComponent(url.pathname));if(!file.startsWith(base+path.sep)){res.writeHead(403);res.end();return;}}
   if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return;}
   const mime={'.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp'};res.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream');res.end(fs.readFileSync(file));
  }catch(e){console.error(e);res.writeHead(500);res.end('Preview request failed');}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)});console.log(`Local: http://127.0.0.1:${port}/`);return {server,binding,close:()=>new Promise(resolve=>server.close(()=>{binding.close();resolve()}))};
}
if(process.argv[1]&&path.resolve(process.argv[1])===path.resolve('scripts/local-preview.mjs'))await startPreview();
