import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
import {build} from 'rolldown';
import {compile} from '@tailwindcss/node';
import {Scanner} from '@tailwindcss/oxide';
const root=process.cwd();fs.mkdirSync('.sites-runtime/preview',{recursive:true});
const alias={'@':root};
await build({input:'preview/client.tsx',platform:'browser',resolve:{alias},transform:{define:{'process.env.NODE_ENV':JSON.stringify('production'),'import.meta.env.DEV':'true'},jsx:{runtime:'automatic'}},output:{file:'.sites-runtime/preview/app.js',format:'esm',minify:true}});
await build({input:'preview/routes.ts',platform:'node',resolve:{alias},transform:{define:{'import.meta.env.DEV':'true'}},plugins:[{name:'local-server-bindings',resolveId(id){if(['cloudflare:workers','next/headers','next/navigation'].includes(id))return '\0local:'+id},load(id){if(id==='\0local:cloudflare:workers')return 'export const env=globalThis.__weddingPreviewEnv';if(id==='\0local:next/headers')return 'export async function headers(){return globalThis.__weddingPreviewContext.getStore().headers}';if(id==='\0local:next/navigation')return 'export function redirect(url){throw new Error("Redirect: "+url)}'}}],output:{file:'.sites-runtime/preview/routes.mjs',format:'esm'}});
const compiler=await compile(fs.readFileSync('app/globals.css','utf8'),{base:path.join(root,'app'),onDependency:()=>{}});
const scanner=new Scanner({sources:[{base:root,pattern:'app/**/*.{tsx,ts}',negated:false},{base:root,pattern:'components/ui/**/*.{tsx,ts}',negated:false}]});
fs.writeFileSync('.sites-runtime/preview/style.css',compiler.build(scanner.scan()));
const schemaJs=ts.transpileModule(fs.readFileSync('db/schema.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
fs.writeFileSync('.sites-runtime/schema.mjs',schemaJs);
if(!fs.existsSync('drizzle/meta/_journal.json')||JSON.parse(fs.readFileSync('drizzle/meta/_journal.json','utf8')).entries.length===0){
 const {generateSQLiteDrizzleJson,generateSQLiteMigration}=await import('drizzle-kit/api');
 const schema=await import(pathToFileURL(path.join(root,'.sites-runtime/schema.mjs')));
 const prev=await generateSQLiteDrizzleJson({});prev.id='00000000-0000-0000-0000-000000000000';const current=await generateSQLiteDrizzleJson(schema,prev.id);
 const statements=await generateSQLiteMigration(prev,current);
 fs.mkdirSync('drizzle/meta',{recursive:true});fs.writeFileSync('drizzle/0000_wedding.sql',statements.join('\n--> statement-breakpoint\n'));
 fs.writeFileSync('drizzle/meta/0000_snapshot.json',JSON.stringify(current,null,2));fs.writeFileSync('drizzle/meta/_journal.json',JSON.stringify({version:'7',dialect:'sqlite',entries:[{idx:0,version:'6',when:Date.now(),tag:'0000_wedding',breakpoints:true}]},null,2));
}
console.log('Local preview built from the application source; migrations generated.');

