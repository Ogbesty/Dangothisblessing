import {build} from 'rolldown';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
await build({input:'app/review/page.tsx',platform:'node',resolve:{alias:{'@':process.cwd()}},transform:{define:{'process.env.NODE_ENV':JSON.stringify('production'),'import.meta.env.DEV':'false'},jsx:{runtime:'automatic'}},plugins:[{name:'review-auth-test',resolveId(id){if(id==='next/headers'||id==='next/navigation')return '\0test:'+id},load(id){if(id==='\0test:next/headers')return 'export async function headers(){return globalThis.__reviewHeaders}';if(id==='\0test:next/navigation')return 'export function redirect(url){throw new Error(url)}'}}],output:{file:'.sites-runtime/tests/review-page.mjs',format:'esm'}});
const {default:page}=await import(pathToFileURL(path.resolve('.sites-runtime/tests/review-page.mjs')));
for(const [email,allowed] of [[null,false],['stranger@example.com',false],['seedy@sites.test',false],['danikaypay@gmail.com',true],['ogbeborbenedict@gmail.com',true],['Danikaypay@gmail.com',true]]){
 globalThis.__reviewHeaders=new Headers(email?{'oai-authenticated-user-id':'test-id','oai-authenticated-user-email':email}:{});
 const result=await page();assert.equal(result.props.reviewMode===true,allowed);console.log('PASS reviewer access:',email??'anonymous',allowed?'allowed':'denied');
}
