# Daniel & Blessing wedding website

The guest invitation is intended to be public. There is no scheduled launch date; the couple will decide when to share the hosted link.

## Local preview

Invitation: http://127.0.0.1:5173/
Admin: http://127.0.0.1:5173/admin

Run Start-preview.ps1 if the preview stops. These links work only on this computer.

Admin now uses the password selected in the conversation. No ChatGPT/email login is required. The password is stored locally only as a salted PBKDF2 hash, alongside a random session signing secret, in ignored .sites-runtime/admin-secrets.json. Never publish this runtime folder. Local sign-in shortcuts and identity-header authentication have been removed. Sessions expire after two hours, cookies are HttpOnly and SameSite=Strict (also Secure on HTTPS), and login attempts are limited. Password changes require a new hash and signing secret to revoke old sessions. This is a shared admin login, so audit entries identify the shared wedding administrator rather than an individual person.

## Publishing status

No public URL has been created. The Sites publishing connection/tools are unavailable in this session. Hosting must provision D1, apply drizzle migrations, and configure ADMIN_PASSWORD_HASH and ADMIN_SESSION_SECRET as server secrets from the ignored local configuration. These values must never enter browser bundles or source control. The production build, hosting and HTTPS authentication still need verification. Publish with a public guest audience; protect every admin API through the password session. There is no automatic publication on October 12.

## Guest and admin behavior

Guests view wedding details, photographs, countdown, love story, Aso Ebi instructions, gifts and approved wishes. Payments go directly to Danikay Tech - Dangothisblessing2026, 5394612926, Moniepoint MFB. Guests send receipts to https://wa.me/2348182472868.

Pending payments do not reduce gift balances. Admin must paste the exact contribution reference from WhatsApp, verify receipt and bank credit, and enter a unique bank transaction reference. Confirmation reduces the balance; fully funded items show Item gifted. Cash gifts remain open-ended. Wishes stay hidden until approved. Admin can edit gift targets and wording.

## Validation

Local preview build and TypeScript passed. scripts/test-workflows.mjs passed 42 isolated checks including login, tampered cookies, origin protection, rate limits, wish moderation, partial payments, duplicate confirmations, funding limits and persistence. The hosted build and browser visual inspection remain unverified.

Source photos/products are in public/photos and public/gifts. Persistent local data is .sites-runtime/preview/wedding.sqlite. Isolated test data stays separate. The former restricted review page has been replaced by the public invitation.
