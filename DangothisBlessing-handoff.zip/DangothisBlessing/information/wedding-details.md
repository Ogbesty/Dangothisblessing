# Wedding website content

- Couple: Daniel Oluwafemi & Blessing Anuoluwapo
- Preferred display names: Daniel and Blessing
- Wedding date: Saturday, 14 November 2026
- Colours: Purple & Gold
- Hashtag (as supplied): #DangothisBlessing
- Reference: https://adefola.vercel.app/
- Photo archive: C:/Users/USER/Documents/Bluetooth/wedding photo bump.zip
- Selected front-page image: e.jpg, copied to wedding-photo-bump/front-page.jpg
- Selection: warm embrace, clear smiling faces, neutral background that complements purple and gold. Preserve both faces when cropping; use a portrait image beside text on desktop if necessary.
- Full love story: love-story-original.txt (verbatim supplied text, including two garbled emoji sequences to tidy for publication).

## Events and invitation contacts

Transcribed from the supplied wedding invitation:
- Families: Kayode and Oderinde.
- Ceremony: 14 November 2026, 10:00 AM, MFM Ayobo Mega Region, 5/7 Onikanga Road, off Camp Davies Road, Ayobo-Ipaja, Lagos.
- Reception: 14 November 2026, 1:00 PM, Ronite Event Center, Camp Davies Way, Abbot Bus-stop, Along Ayobo - Ishefun Road, Ayobo, Lagos.
- General enquiries / invitation RSVP contacts: Daniel — 08086681725; Philip — 08053916863.
- Countdown requested to the wedding date. Proposed exact target: ceremony start, 2026-11-14T10:00:00+01:00 (Lagos time).
- User-supplied venue directions: https://maps.google.com/maps/place//data=!4m2!3m1!1s0x103b9b49e9cd24a7:0xdf9743e57941a1c4?entry=s&sa=X&ved=2ahUKEwj5sLi8i4yXAxWQUkEAHVtVCiYQ4kB6BAgWEAA&hl=en
- User confirmed the supplied map is for the reception. Church uses its invitation-card address only; no church map required.
- RSVP uses the contacts on the invitation card; no attendance form requested.

## Website and moderation decisions

- Preferred website name: DangothisBlessing. Exact domain/hosting address not yet selected or availability checked.
- Launch date: no fixed date. User will share the public guest link whenever they choose.
- Provide a private preview before launch for review and editing; publish the public site after the user's final review. The user wants to be able to view and edit before launch.
- Guest wishes require approval before public display.
- Proposed implementation: private authenticated admin area and shared persistent database. New wishes are pending and excluded from public reads. Admin can approve or reject; only approved name/message pairs appear publicly.
- Admin sign-in email: ogbeborbenedict@gmail.com. This is recorded for future setup; access has not yet been provisioned.
- Additional admin sign-in email: Danikaypay@gmail.com. Both email addresses should have admin access when implemented; neither has been provisioned yet.
- Admin/receipt WhatsApp contact: https://wa.me/2348182472868. A WhatsApp contact link is not admin authentication; approvals occur in the authenticated admin area.

## Gift registry requirements

- Six item gift cards, each with product image, target amount, confirmed contributions and remaining amount, plus a seventh "Gift in cash" option.
- Gift in cash: proposed open-ended contribution of any positive amount to the same account, with the same receipt and manual confirmation workflow. No item funding target, remaining balance or "Item gifted" closure; keep separate from item contributions.
- Selecting a gift opens the couple's bank details and contribution instructions, rather than sending guests to retailer checkout.
- Guests may contribute part or all of the remaining amount by direct bank transfer to the couple.
- Payment receipts must be sent to https://wa.me/2348182472868 before confirmation.
- Proposed flow: select gift and amount, create a unique reference, show bank details, and offer a WhatsApp button with gift/amount/reference prefilled. Guest attaches receipt in WhatsApp themselves.
- Payment is pending until the couple checks the bank credit and manually confirms the amount against the gift in the private admin area. Sending a receipt or clicking WhatsApp alone does not confirm payment.
- Remaining amount = target minus confirmed contributions, with display floored at zero. Fully funded gifts display exactly "Item gifted" and disable further contributions.
- Confirmations must be recorded once only; retain transaction references and an audit trail. Pending transfers can overlap, so flag excess payments for manual resolution, never silently reallocate them.
- Keep contributor details and receipts private. Receipts stay in WhatsApp unless a later upload feature is requested.
- Account name (exactly as supplied): Danikay Tech - Dangothisblessing2026
- Account number: 5394612926
- Bank: Moniepoint MFB
- Gift funding targets use item prices only, excluding delivery costs. Final prices still need verification. Do not automatically change targets with retailer price fluctuations.

Gift source URLs supplied by user:
1. Microwave: https://www.jumia.com.ng/hisense-2026-digital-microwave-oven-20l-419251112.html
2. Cookware: https://www.jumia.com.ng/brocook-10pcs-die-cast-non-stick-granite-cookware-set-with-glass-lids-418866135.html
3. Air conditioner: https://www.jumia.com.ng/lontor-1.5hp-horse-power-split-air-conditioner-energy-saving-ctl-ac-js12n-286373642.html
4. Washing machine: https://www.jumia.com.ng/hisense-8kg-inverter-washing-machine-front-load-420257495.html
5. Juice extractor: https://www.jumia.com.ng/mirta-exquisite-juice-extrator-419301567.html
6. Industrial sewing machine: https://www.jumia.com.ng/generic-overlock-weaving-industrial-sewing-machine-419778504.html
7. Gift in cash: no retailer URL; direct contribution to the account above.

Source check on 2026-10-01: all six exact product pages and images were subsequently retrieved directly. Initial targets excluding delivery: microwave ₦119,000; cookware ₦79,920; air conditioner ₦290,000; washing machine ₦459,999; juice extractor ₦286,850; industrial sewing machine ₦134,888. Source URLs and image metadata are saved under dangothisblessing/lib/data/product-sources.json.

## Build status

- Local working preview built in outputs/dangothisblessing; launch with Start-preview.ps1 if it stops.
- Local invitation: http://127.0.0.1:5173/ ; local admin: http://127.0.0.1:5173/admin.
- Implemented: invitation, countdown, story, gallery, event details, reception map, Aso Ebi/access-card notice, RSVP contacts, item and cash contributions, bank details, WhatsApp receipt instructions, moderated wishes and admin wording/target edits.
- 36 isolated workflow checks and TypeScript validation passed after adding exact WhatsApp contribution-reference validation. Current preview has no test contributions or guest wishes.
- Admin confirmation now requires the contribution reference copied from WhatsApp to exactly match the selected record, plus explicit receipt and bank-credit checks. The matching reference is logged with the separate bank transaction reference. The site cannot independently read WhatsApp messages.
- Requested next: stronger live admin sign-in and an external review link. Recommended: MFA on the two allowed admin accounts, provider-enforced session limits, and a private reviewer preview with no admin privileges or real-payment testing. These deployment/auth settings are not provisioned yet.
- Hosted publishing unavailable because Sites native hosting tools are absent. Real email sign-in and hosted storage still need connection and verification before guests can use the site.
- Browser visual/WebMCP QA unavailable because the browser inspection runtime failed to initialize. Review the rendered preview before launch.

## Guest instructions

Dear family and friends,

As we prepare to celebrate this beautiful occasion together, we would like to kindly inform everyone that, due to the limited capacity of the reception hall, entry into the wedding reception will be strictly by ACCESS CARD.

Your Access Card will be issued upon purchase of the Aso Ebi.

- 1 Access Card admits 1 person only.
- Kindly come along with your Access Card, as it will be required at the entrance.

For Aso Ebi (Ankara) purchases and enquiries, kindly send a direct WhatsApp message to:
- Blessing — 09064661164
- Daniel — 08182472868

Aso Ebi prices:
- 3 yards — ₦7,500
- 4 yards — ₦10,000
- 5 yards — ₦12,500
- 6 yards — ₦15,000

Aso Ebi sales close on October 31 (2026 inferred from the wedding date) to allow sufficient time for proper preparation and distribution.

We sincerely appreciate your love, understanding, cooperation, and support as we prepare to celebrate this very special day together. Thank you so much for joining us.

The guest notice above removes garbled emoji characters and normalizes formatting without changing the instructions. General invitation contacts and Aso Ebi contacts are distinct; preserve both sets in their respective sections.

## Latest requested changes

- Replace gallery photo a.jpg with d.jpg (Blessing seated beside Daniel in matching light outfits). Remove a.jpg from the site assets, preserving the original supplied photos.
- Brief floating heart emoji animation when the invitation opens; respect reduced-motion preferences and do not intercept clicks.
- Requested private hosted review copy, restricted to danikaypay@gmail.com and ogbeborbenedict@gmail.com. View-only access, no admin rights granted by review access. Publishing still requires available hosting/access-management tools.

- Latest access decision: public guest invitation; shared password admin login replaces email sign-in. Password is kept as a salted hash in ignored local runtime configuration, not in browser code. Hosted secrets and public deployment still require the Sites connection.
