# DangothisBlessing — Claude publishing handoff

This package contains the complete authored application and website assets. No hosted site currently exists. The public launch has no fixed date; the user chooses when to share the guest link.

## Package
- website/: application source, photos, product images, dependency lock, components, build support, schema and migrations, preview scripts and tests.
- information/: wedding brief and original full love story. The latest decisions in this document override historical status notes in the brief.
- CLAUDE-PROMPT.txt: paste into Claude with the ZIP attached, or run Claude Code in the extracted project.
- private/admin-server-secrets.json: confidential deployment configuration containing a salted password hash and fresh signing secret. Configure server secrets only. This private file must stay outside the deployed source/public tree.
- FILE-MANIFEST.json: paths, sizes and SHA-256 checksums of included application files.

## Latest decisions
Public invitation, no guest login. Shared password admin login, not email allowlisting. Admin password visibility can be toggled. No October 12 launch schedule. Bank: Danikay Tech - Dangothisblessing2026 / 5394612926 / Moniepoint MFB. Receipt WhatsApp: https://wa.me/2348182472868. The hands-raised a.jpg is removed from the site; d.jpg replaces it. Floating hearts play briefly on opening and respect reduced motion.

## Runtime
Node >=22.13; local runtime used Node 24. Install from package-lock.json (npm ci). Vinext/React server routes reference cloudflare:workers env.DB. Cloudflare Workers/D1 is the closest deployment match. The bundled Sites build configuration has a placeholder D1 database ID and no hosted project_id; replace hosting-specific configuration for the chosen provider, rather than deploying placeholders.

ADMIN_PASSWORD_HASH and ADMIN_SESSION_SECRET must be available to the server through its Cloudflare env (or adapted equivalent). The password hash format is salt:hex-PBKDF2-SHA256, 100000 iterations, 32 bytes, with the salt encoded as UTF-8. The supplied signing secret is freshly generated for this handoff. For local preview, create .sites-runtime/ and copy private/admin-server-secrets.json to .sites-runtime/admin-secrets.json; run node scripts/build-local-preview.mjs then node scripts/local-preview.mjs from website/. The local server stays on 127.0.0.1 and must not be used as an internet server.

Database schema: db/schema.ts. Immutable initial migration: drizzle/0000_wedding.sql. Apply migrations before serving API routes. Gift targets initialize on public-data requests; production data is never browser localStorage. No live payment/wish records exist to migrate. Tests use isolated SQLite files. No user account or cloud credentials are included.

## Checks and limitations
42 workflow checks passed after password login implementation; TypeScript passed after Show/Hide addition. Windows sandbox blocked standard Vite/Cloudflare subprocesses, so the source has a functional local Rolldown/SQLite preview. Normal production build remains unverified and must be made to pass on the deployment machine. Browser visual inspection was unavailable. Older scripts/test-review-access.mjs exercises the superseded email review model and is not an acceptance test for the current public/password setup. app/review now displays the public invitation.

Recommended checks: node scripts/build-local-preview.mjs; node scripts/test-workflows.mjs; npx tsc --noEmit; npm run build after adapting deployment configuration. Do not claim production publishing has succeeded from local checks alone.

Excluded: node_modules, Git history, caches, generated bundles, local databases/test records and local session secret. All selected website photos and product images are included. The full original unused photoshoot ZIP is not needed for publishing and is not included.
